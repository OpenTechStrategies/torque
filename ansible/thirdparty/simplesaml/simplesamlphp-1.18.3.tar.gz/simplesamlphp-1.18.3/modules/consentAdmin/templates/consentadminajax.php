<?php
echo $res;
