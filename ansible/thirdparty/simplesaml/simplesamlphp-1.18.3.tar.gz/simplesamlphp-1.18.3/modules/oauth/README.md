# simplesamlphp-module-oauth
Ancient Oauth1 module for SimpleSAMLphp

This module was extracted from SimpleSAMLphp 1.17.
It will not be included in 2.0 anymore, but can be installed separately.

To install this legacy module, use the following command from the SimpleSAMLphp installation directory:

`composer.phar require simplesamlphp/simplesamlphp-module-oauth`
