Upgrade notes for SimpleSAMLphp 1.12
====================================

  * PHP version 5.3 is now required.
